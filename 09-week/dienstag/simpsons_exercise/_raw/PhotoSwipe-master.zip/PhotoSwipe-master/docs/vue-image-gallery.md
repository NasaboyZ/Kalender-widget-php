---
id: vue-image-gallery
title: Image Gallery for Vue.js
sidebar_label: for Vue
---

Here's an example on how to use PhotoSwipe with Vue to create a simple image gallery. [Browse and edit code on Stackblitz](https://stackblitz.com/edit/vue-hatnqg).

<iframe src="https://stackblitz.com/edit/vue-hatnqg?embed=1&file=src/SimpleGallery.vue&hideNavigation=1"></iframe>

There is also an unofficial [Vue gallery component by @hzpeng57](https://github.com/hzpeng57/vue-preview-imgs) that could be very useful.

   
   
